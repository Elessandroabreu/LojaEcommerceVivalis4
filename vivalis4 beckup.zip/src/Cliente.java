public class Cliente {

    String cpf;
    int compras;

    public Cliente(String cpf) {
        this.cpf = cpf;
        this.compras = 0;
    }
}


